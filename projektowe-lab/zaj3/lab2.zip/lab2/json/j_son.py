import requests
import json

site = "https://danepubliczne.imgw.pl/api/data/synop/id/12566"
r = requests.get(site)

print(r.text)

d = json.loads(r.text)

print(d)

for k in d:
  print(k,d[k])



